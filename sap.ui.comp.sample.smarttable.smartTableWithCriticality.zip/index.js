sap.ui.require([
	"sap/m/Shell",
	"sap/m/App",
	"sap/m/Page",
	"sap/ui/core/ComponentContainer"
], function(
	Shell, App, Page, ComponentContainer) {
	"use strict";

	sap.ui.getCore().attachInit(function() {
		new Shell ({
			app : new App ({
				pages : [
					new Page({
						title : "Smart (Grid) Table with Criticality",
						enableScrolling : false,
						content : [
							new ComponentContainer({
								height : "100%", name : "sap.ui.comp.sample.smarttable.smartTableWithCriticality",
								settings : {
									id : "sap.ui.comp.sample.smarttable.smartTableWithCriticality"
								}
							})
						]
					})
				]
			})
		}).placeAt("content");
	});
});
